//
//  equipmentApp.swift
//  equipment
//
//  Created by .. on 7/11/25.
//

import SwiftUI

@main
struct equipmentApp: App {
    var body: some Scene {
        WindowGroup {
            HomescreenView()
        }
    }
}
