//
//  SAPChallenge3Tests.swift
//  SAPChallenge3Tests
//
//  Created by Tessa Lee on 6/11/25.
//

import Testing
@testable import SAPChallenge3

struct SAPChallenge3Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
