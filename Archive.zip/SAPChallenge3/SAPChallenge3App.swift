//
//  SAPChallenge3App.swift
//  SAPChallenge3
//
//  Created by Tessa Lee on 6/11/25.
//

import SwiftUI

@main
struct SAPChallenge3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
